tag @a[scores={dice=2}] add dice_temp

title @a title {"text":"👁 2點的老鼠請睜眼","color":"gold","bold":true}
execute if entity @a[tag=dice_temp] run title @a subtitle {"text":"請觀察其他玩家...","color":"yellow"}


playsound minecraft:entity.villager.yes master @a[tag=dice_temp] ~ ~ ~ 1
execute as @a[tag=dice_temp] run tp @s -10 -60 33

scoreboard players set #observe_timer dummy 200
bossbar set dice:observe value 200
bossbar set dice:observe visible true
bossbar set dice:observe players @a

schedule clear dice:tick/tick_boss
schedule function dice:tick/tick_boss 1t

schedule function dice:step2/3 140t
