title @a times 10 20 10
title @a title {"text":"3","color":"red","bold":true}
playsound minecraft:block.note_block.pling master @a ~ ~ ~ 1

schedule clear dice:step2/2
schedule function dice:step2/2 20t