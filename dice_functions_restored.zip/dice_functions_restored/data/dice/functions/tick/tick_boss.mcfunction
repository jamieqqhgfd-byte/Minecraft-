scoreboard players remove #observe_timer dummy 1
execute store result bossbar dice:observe value run scoreboard players get #observe_timer dummy

execute if score #observe_timer dummy matches 1.. run schedule function dice:tick/tick_boss 1t
execute unless score #observe_timer dummy matches 1.. run bossbar set dice:observe visible false